# Wishbone to AXI bridge

This module bridges a Wishbone slave interface to an ARM® AMBA® AXI
interface.

It is very stupid at the moment and ignores all bulk data transfers,
which makes it slow in most environments. Please feel free to extend
and improve.
